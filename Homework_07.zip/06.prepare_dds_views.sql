-- Создаём VIEW для добавления данных в Data Vault

-- Hub user (загрузка из MDM)
DROP VIEW IF EXISTS sperfilyev.dds_v_hub_user_mdm_etl;
CREATE VIEW sperfilyev.dds_v_hub_user_mdm_etl AS (
WITH records_numbered AS (
    SELECT user_pk,
           user_key,
           load_dts,
           rec_source,
           row_number() OVER (PARTITION BY user_pk ORDER BY load_dts ASC) AS row_num
    FROM sperfilyev.ods_t_user_hashed),
     records_rank_1 AS (
         SELECT user_pk, user_key, load_dts, rec_source
         FROM records_numbered
         WHERE row_num = 1),
     records_to_insert AS (
         SELECT a.*
         FROM records_rank_1 AS a
                  LEFT JOIN sperfilyev.dds_t_hub_user AS h
                            ON a.user_pk = h.user_pk
         WHERE h.user_pk IS NULL
     )
SELECT *
FROM records_to_insert
    );
-- Проверка. Должны появляться новые абоненты, которых ещё нет в dds hub user
select count(*), count (distinct user_pk), count(distinct user_key) from sperfilyev.dds_v_hub_user_mdm_etl;
select * from sperfilyev.dds_v_hub_user_mdm_etl order by user_key;

-- Hub user (загрузка из payment)
DROP VIEW IF EXISTS sperfilyev.dds_v_hub_user_payment_etl;
CREATE VIEW sperfilyev.dds_v_hub_user_payment_etl AS (
WITH records_numbered AS (
    SELECT user_pk,
           user_key,
           load_dts,
           rec_source,
           row_number() OVER (PARTITION BY user_pk ORDER BY load_dts ASC) AS row_num
    FROM sperfilyev.ods_t_payment_hashed),
     records_rank_1 AS (
         SELECT user_pk, user_key, load_dts, rec_source
         FROM records_numbered
         WHERE row_num = 1),
     records_to_insert AS (
         SELECT a.*
         FROM records_rank_1 AS a
                  LEFT JOIN sperfilyev.dds_t_hub_user AS h
                            ON a.user_pk = h.user_pk
         WHERE h.user_pk IS NULL
     )
SELECT *
FROM records_to_insert
    );
-- Проверка
select * from sperfilyev.dds_v_hub_user_payment_etl limit 20;
select count(*) from sperfilyev.dds_v_hub_user_payment_etl;

-- Hub account (загрузка из payment)
DROP VIEW IF EXISTS sperfilyev.dds_v_hub_account_etl;
CREATE VIEW sperfilyev.dds_v_hub_account_etl AS (
WITH records_numbered AS (
    SELECT account_pk,
           account_key,
           load_dts,
           rec_source,
           row_number() OVER (PARTITION BY account_pk order by load_dts ASC) AS row_num
    FROM sperfilyev.ods_t_payment_hashed),
     records_rank_1 AS (
         SELECT account_pk, account_key, load_dts, rec_source
         FROM records_numbered
         WHERE row_num = 1),
     records_to_insert AS (
         SELECT a.*
         FROM records_rank_1 AS a
                  LEFT JOIN sperfilyev.dds_t_hub_account AS h
                            ON a.account_pk = h.account_pk
         WHERE h.account_pk IS NULL
     )
SELECT *
FROM records_to_insert
    );
-- Проверка
select * from sperfilyev.dds_v_hub_account_etl order by account_key;
select count(*), count(distinct account_key) from sperfilyev.dds_v_hub_account_etl;

-- Hub billng_period (загрузка из payment)
DROP VIEW IF EXISTS sperfilyev.dds_v_hub_billing_period_etl;
CREATE VIEW sperfilyev.dds_v_hub_billing_period_etl AS (
with records_numbered AS (
    SELECT billing_period_pk,
           billing_period_key,
           load_dts,
           rec_source,
           row_number() OVER (PARTITION BY billing_period_pk ORDER BY load_dts ASC) AS row_num
    FROM sperfilyev.ods_t_payment_hashed),
     records_rank_1 AS (
         SELECT billing_period_pk, billing_period_key, load_dts, rec_source
         FROM records_numbered
         WHERE row_num = 1),
     records_to_insert AS (
         SELECT a.*
         FROM records_rank_1 AS a
                  LEFT JOIN sperfilyev.dds_t_hub_billing_period AS h
                            ON a.billing_period_pk = h.billing_period_pk
         WHERE h.billing_period_pk IS NULL
     )
SELECT *
FROM records_to_insert
    );
-- Проверка
select * from sperfilyev.dds_v_hub_billing_period_etl order by billing_period_key;
select count(*), count(distinct billing_period_key) from sperfilyev.dds_v_hub_billing_period_etl;

-- Hub paysys (загрузка из payment)
DROP VIEW IF EXISTS sperfilyev.dds_v_hub_paysys_etl;
CREATE VIEW sperfilyev.dds_v_hub_paysys_etl AS (
with records_numbered AS (
    SELECT paysys_pk,
           paysys_key,
           load_dts,
           rec_source,
           row_number() OVER (PARTITION BY paysys_pk ORDER BY load_dts ASC) AS row_num
    FROM sperfilyev.ods_t_payment_hashed),
     records_rank_1 AS (
         SELECT paysys_pk, paysys_key, load_dts, rec_source
         FROM records_numbered
         WHERE row_num = 1),
     records_to_insert AS (
         SELECT a.*
         FROM records_rank_1 AS a
                  LEFT JOIN sperfilyev.dds_t_hub_paysys AS h
                            ON a.paysys_pk = h.paysys_pk
         WHERE h.paysys_pk IS NULL
     )
SELECT *
FROM records_to_insert
    );
-- Проверка
select * from sperfilyev.dds_v_hub_paysys_etl order by paysys_key;
select count(*), count(distinct paysys_key) from sperfilyev.dds_v_hub_paysys_etl;

-- Hub service (загрузка из issue)
DROP VIEW IF EXISTS sperfilyev.dds_v_hub_service_issue_etl;
CREATE VIEW sperfilyev.dds_v_hub_service_issue_etl AS (
with records_numbered AS (
    SELECT service_pk,
           service_key,
           load_dts,
           rec_source,
           row_number() OVER (PARTITION BY service_pk ORDER BY load_dts ASC) AS row_num
    FROM sperfilyev.ods_t_issue_hashed),
     records_rank_1 AS (
         SELECT service_pk, service_key, load_dts, rec_source
         FROM records_numbered
         WHERE row_num = 1),
     records_to_insert AS (
         SELECT a.*
         FROM records_rank_1 AS a
                  LEFT JOIN sperfilyev.dds_t_hub_service AS h
                            ON a.service_pk = h.service_pk
         WHERE h.service_pk IS NULL
     )
SELECT *
FROM records_to_insert
    );
-- Проверка
select * from sperfilyev.dds_v_hub_service_issue_etl order by service_key;
select count(*), count(distinct service_key) from sperfilyev.dds_v_hub_service_issue_etl;

-- Hub service (загрузка из billing)
DROP VIEW IF EXISTS sperfilyev.dds_v_hub_service_billing_etl;
CREATE VIEW sperfilyev.dds_v_hub_service_billing_etl AS (
with records_numbered AS (
    SELECT service_pk,
           service_key,
           load_dts,
           rec_source,
           row_number() OVER (PARTITION BY service_pk ORDER BY load_dts ASC) AS row_num
    FROM sperfilyev.ods_t_billing_hashed),
     records_rank_1 AS (
         SELECT service_pk, service_key, load_dts, rec_source
         FROM records_numbered
         WHERE row_num = 1),
     records_to_insert AS (
         SELECT a.*
         FROM records_rank_1 AS a
                  LEFT JOIN sperfilyev.dds_t_hub_service AS h
                            ON a.service_pk = h.service_pk
         WHERE h.service_pk IS NULL
     )
SELECT *
FROM records_to_insert
    );
-- Проверка
select * from sperfilyev.dds_v_hub_service_billing_etl order by service_key;
select count(*), count(distinct service_key) from sperfilyev.dds_v_hub_service_billing_etl;

-- Hub tariff (загрузка из billing)
DROP VIEW IF EXISTS sperfilyev.dds_v_hub_tariff_etl;
CREATE VIEW sperfilyev.dds_v_hub_tariff_etl AS (
with records_numbered AS (
    SELECT tariff_pk,
           tariff_key,
           load_dts,
           rec_source,
           row_number() OVER (PARTITION BY tariff_pk ORDER BY load_dts ASC) AS row_num
    FROM sperfilyev.ods_t_billing_hashed),
     records_rank_1 AS (
         SELECT tariff_pk, tariff_key, load_dts, rec_source
         FROM records_numbered
         WHERE row_num = 1),
     records_to_insert AS (
         SELECT a.*
         FROM records_rank_1 AS a
                  LEFT JOIN sperfilyev.dds_t_hub_tariff AS h
                            ON a.tariff_pk = h.tariff_pk
         WHERE h.tariff_pk IS NULL
     )
SELECT *
FROM records_to_insert
    );
-- Проверка
select * from sperfilyev.dds_v_hub_tariff_etl order by tariff_key;
select count(*), count(distinct tariff_key) from sperfilyev.dds_v_hub_tariff_etl;

-- Hub device (загрузка из traffic)
DROP VIEW IF EXISTS sperfilyev.dds_v_hub_device_etl;
CREATE VIEW sperfilyev.dds_v_hub_device_etl AS (
with records_numbered AS (
    SELECT device_pk,
           device_key,
           load_dts,
           rec_source,
           row_number() OVER (PARTITION BY device_pk ORDER BY load_dts ASC) AS row_num
    FROM sperfilyev.ods_t_traffic_hashed),
     records_rank_1 AS (
         SELECT device_pk, device_key, load_dts, rec_source
         FROM records_numbered
         WHERE row_num = 1),
     records_to_insert AS (
         SELECT a.*
         FROM records_rank_1 AS a
                  LEFT JOIN sperfilyev.dds_t_hub_device AS h
                            ON a.device_pk = h.device_pk
         WHERE h.device_pk IS NULL
     )
SELECT *
FROM records_to_insert
    );
-- Проверка
select * from sperfilyev.dds_v_hub_device_etl order by device_key;
select count(*), count(distinct device_key) from sperfilyev.dds_v_hub_device_etl;

-- =============================================================================
-- LINK'и

-- Link payment (user - account - billing_period - paysys)
DROP VIEW IF EXISTS sperfilyev.dds_v_lnk_payment_etl;
CREATE VIEW sperfilyev.dds_v_lnk_payment_etl AS (
SELECT DISTINCT src.payment_pk,
                src.user_pk,
                src.billing_period_pk,
                src.account_pk,
                src.paysys_pk,
                src.effective_from,
                src.load_dts,
                src.rec_source
FROM sperfilyev.ods_t_payment_hashed AS src
         LEFT JOIN sperfilyev.dds_t_lnk_payment AS l
                   ON src.payment_pk = l.payment_pk
WHERE l.payment_pk IS NULL
);
-- Проверка
select count(*) from sperfilyev.dds_v_lnk_payment_etl;
select * from sperfilyev.dds_v_lnk_payment_etl limit 20;

-- Link issue (user - service)
DROP VIEW IF EXISTS sperfilyev.dds_v_lnk_issue_etl;
CREATE VIEW sperfilyev.dds_v_lnk_issue_etl AS (
SELECT DISTINCT src.issue_pk,
                src.user_pk,
                src.service_pk,
                src.effective_from,
                src.load_dts,
                src.rec_source
FROM sperfilyev.ods_t_issue_hashed AS src
         LEFT JOIN sperfilyev.dds_t_lnk_issue AS l
                   ON src.issue_pk = l.issue_pk
WHERE l.issue_pk IS NULL
);
-- Проверка
select count(*) from sperfilyev.dds_v_lnk_issue_etl;
select * from sperfilyev.dds_v_lnk_issue_etl limit 20;

-- Link billing (user - billing_period - service - tariff)
DROP VIEW IF EXISTS sperfilyev.dds_v_lnk_billing_etl;
CREATE VIEW sperfilyev.dds_v_lnk_billing_etl AS (
SELECT DISTINCT src.billing_pk,
                src.user_pk,
                src.billing_period_pk,
                src.service_pk,
                src.tariff_pk,
                src.effective_from,
                src.load_dts,
                src.rec_source
FROM sperfilyev.ods_t_billing_hashed AS src
         LEFT JOIN sperfilyev.dds_t_lnk_billing AS l
                   ON src.billing_pk = l.billing_pk
WHERE l.billing_pk IS NULL
);
-- Проверка
select count(*) from sperfilyev.dds_v_lnk_billing_etl;
select * from sperfilyev.dds_v_lnk_billing_etl limit 20;

-- Link traffic
DROP VIEW IF EXISTS sperfilyev.dds_v_lnk_traffic_etl;
CREATE VIEW sperfilyev.dds_v_lnk_traffic_etl AS (
SELECT DISTINCT src.traffic_pk,
                src.user_pk,
                src.device_pk,
                src.effective_from,
                src.load_dts,
                src.rec_source
FROM sperfilyev.ods_t_traffic_hashed AS src
         LEFT JOIN sperfilyev.dds_t_lnk_traffic AS l
                   ON src.traffic_pk = l.traffic_pk
WHERE l.traffic_pk IS NULL
);
-- Проверка
select count(*) from sperfilyev.dds_v_lnk_traffic_etl;
select * from sperfilyev.dds_v_lnk_traffic_etl limit 20;

-- =============================================================================
-- SATELLITE'ы

-- Sat user_mdm (загрузка из MDM)
DROP VIEW IF EXISTS sperfilyev.dds_v_sat_user_mdm_etl;
CREATE VIEW sperfilyev.dds_v_sat_user_mdm_etl AS (
WITH source_data AS (
    SELECT user_pk,
           user_hashdiff,
           legal_type,
           district,
           billing_mode,
           is_vip,
           effective_from,
           load_dts,
           rec_source
    FROM sperfilyev.ods_t_user_hashed
),
     update_records AS (
         SELECT s.*
         FROM sperfilyev.dds_t_sat_user_mdm AS s
                  JOIN source_data AS src
                       ON s.user_pk = src.user_pk
     ),
     latest_records AS (
         SELECT *
         FROM (
                  SELECT user_pk,
                         user_hashdiff,
                         load_dts,
                         rank() OVER (PARTITION BY user_pk ORDER BY load_dts DESC) AS row_rank
                  FROM update_records
              ) AS ranked_recs
         WHERE row_rank = 1),
     records_to_insert AS (
         SELECT DISTINCT a.*
         FROM source_data AS a
                  LEFT JOIN latest_records
                            ON latest_records.user_hashdiff = a.user_hashdiff AND
                               latest_records.user_pk = a.user_pk
         WHERE latest_records.user_hashdiff IS NULL
     )
SELECT * FROM records_to_insert);
-- Проверка. Должны выводиться записи для всех новых абонентов
select count(*) from sperfilyev.dds_v_sat_user_mdm_etl;
select * from sperfilyev.dds_v_sat_user_mdm_etl;

-- Sat user (загрузка из payment)
-- Sat payment (загрузка из payment)
-- Sat issue (загрузка из issue)
-- Sat billing (загрузка из billing)
-- Sat traffic (загрузка из traffic)
-- Sat device (загрузка из traffic)

-- ЭТИ САТЕЛЛИТЫ БУДУТ В AIRFLOW (ЗАГРУЗКА ПО БАТЧАМ. 1 БАТЧ = 1 ГОД)