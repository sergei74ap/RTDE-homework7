-- Создаём структуру для слоя DDS DWH:

-- Для HUB'ов
-- Создать. Hub User
drop table if exists sperfilyev.dds_t_hub_user cascade;
create table sperfilyev.dds_t_hub_user
(
    user_pk    text,
    user_key   text,
    load_dts   timestamp,
    rec_source text
) distributed randomly;

-- Создать. Hub Account
drop table if exists sperfilyev.dds_t_hub_account cascade;
create table sperfilyev.dds_t_hub_account
(
    account_pk  text,
    account_key text,
    load_dts    timestamp,
    rec_source  text
)  distributed randomly;

-- Создать. Hub Billing_period
drop table if exists sperfilyev.dds_t_hub_billing_period cascade;
create table sperfilyev.dds_t_hub_billing_period
(
    billing_period_pk  text,
    billing_period_key text,
    load_dts           timestamp,
    rec_source         text
)  distributed randomly;

-- Создать. Hub Payment system (Paysys)
drop table if exists sperfilyev.dds_t_hub_paysys cascade;
create table sperfilyev.dds_t_hub_paysys
(
    paysys_pk  text,
    paysys_key text,
    load_dts   timestamp,
    rec_source text
)  distributed randomly;

-- Создать. Hub Service
drop table if exists sperfilyev.dds_t_hub_service cascade;
create table sperfilyev.dds_t_hub_service
(
    service_pk  text,
    service_key text,
    load_dts    timestamp,
    rec_source  text
)  distributed randomly;

-- Создать. Hub Tariff
drop table if exists sperfilyev.dds_t_hub_tariff cascade;
create table sperfilyev.dds_t_hub_tariff
(
    tariff_pk  text,
    tariff_key text,
    load_dts   timestamp,
    rec_source text
)  distributed randomly;

-- Создать. Hub Device
drop table if exists sperfilyev.dds_t_hub_device cascade;
create table sperfilyev.dds_t_hub_device
(
    device_pk  text,
    device_key text,
    load_dts   timestamp,
    rec_source text
)  distributed randomly;

-- ----------------------------------------------------------------------
-- Для LINK'ов
-- Создать. Link Payment (user - billing_period - account - paysys)
drop table if exists sperfilyev.dds_t_lnk_payment cascade;
create table sperfilyev.dds_t_lnk_payment
(
    payment_pk        text,
    user_pk           text,
    billing_period_pk text,
    account_pk        text,
    paysys_pk         text,
    effective_from    date,
    load_dts          timestamp,
    rec_source        text
)  distributed randomly;

-- Создать. Link Issue (user - service)
drop table if exists sperfilyev.dds_t_lnk_issue cascade;
create table sperfilyev.dds_t_lnk_issue
(
    issue_pk          text,
    user_pk           text,
    service_pk        text,
    effective_from    date,
    load_dts          timestamp,
    rec_source        text
)  distributed randomly;

-- Создать. Link Billing (user - billing_period - service - tariff)
drop table if exists sperfilyev.dds_t_lnk_billing cascade;
create table sperfilyev.dds_t_lnk_billing
(
    billing_pk        text,
    user_pk           text,
    billing_period_pk text,
    service_pk        text,
    tariff_pk         text,
    effective_from    date,
    load_dts          timestamp,
    rec_source        text
)  distributed randomly;

-- Создать. Link Traffic (user - device)
drop table if exists sperfilyev.dds_t_lnk_traffic cascade;
create table sperfilyev.dds_t_lnk_traffic
(
    traffic_pk        text,
    user_pk           text,
    device_pk         text,
    effective_from    date,
    load_dts          timestamp,
    rec_source        text
)  distributed randomly;

-- ----------------------------------------------------------------------
-- Для SATELLITE'ов

-- Создать. Sat User, сателлит хаба (контекст абонента из MDM)
DROP TABLE IF EXISTS sperfilyev.dds_t_sat_user_mdm CASCADE;
CREATE TABLE sperfilyev.dds_t_sat_user_mdm
(
    user_pk        TEXT,
    user_hashdiff  TEXT,
    legal_type     TEXT,
    district       TEXT,
    billing_mode   TEXT,
    is_vip         BOOLEAN,
    effective_from DATE,
    load_dts       TIMESTAMP,
    rec_source     TEXT
)  DISTRIBUTED RANDOMLY;

-- Создать. Sat User, сателлит хаба (контекст абонента из источника payment)
DROP TABLE IF EXISTS sperfilyev.dds_t_sat_user CASCADE;
CREATE TABLE sperfilyev.dds_t_sat_user
(
    user_pk        TEXT,
    user_hashdiff  TEXT,
    phone          TEXT,
    effective_from DATE,
    load_dts       TIMESTAMP,
    rec_source     TEXT
)  DISTRIBUTED RANDOMLY;

-- Создать. Sat Payment (саттелит линка, контекст платежа)
DROP TABLE IF EXISTS sperfilyev.dds_t_sat_payment CASCADE;
CREATE TABLE sperfilyev.dds_t_sat_payment
(
    payment_pk       TEXT,
    payment_hashdiff TEXT,
    pay_doc_num      INT,
    pay_sum          DECIMAL(10, 2),
    effective_from   DATE,
    load_dts         TIMESTAMP,
    rec_source       TEXT
) DISTRIBUTED RANDOMLY;

-- Создать. Sat Issue (саттелит линка, контекст обращения)
DROP TABLE IF EXISTS sperfilyev.dds_t_sat_issue CASCADE;
CREATE TABLE sperfilyev.dds_t_sat_issue
(
    issue_pk       TEXT,
    issue_hashdiff TEXT,
    title          TEXT,
    description    TEXT,
    end_time       TIMESTAMP,
    effective_from DATE,
    load_dts       TIMESTAMP,
    rec_source     TEXT
) DISTRIBUTED RANDOMLY;

-- Создать. Sat Billing (саттелит линка, контекст начисления)
DROP TABLE IF EXISTS sperfilyev.dds_t_sat_billing CASCADE;
CREATE TABLE sperfilyev.dds_t_sat_billing
(
    billing_pk       TEXT,
    billing_hashdiff TEXT,
    billing_sum      DECIMAL(10,2),
    effective_from   DATE,
    load_dts         TIMESTAMP,
    rec_source       TEXT
) DISTRIBUTED RANDOMLY;

-- Создать. Sat Traffic (саттелит линка, контекст сессии передачи данных)
DROP TABLE IF EXISTS sperfilyev.dds_t_sat_traffic CASCADE;
CREATE TABLE sperfilyev.dds_t_sat_traffic
(
    traffic_pk       TEXT,
    traffic_hashdiff TEXT,
    bytes_sent       INT,
    bytes_received   INT,
    effective_from   DATE,
    load_dts         TIMESTAMP,
    rec_source       TEXT
) DISTRIBUTED RANDOMLY;

-- Создать. Sat Device (саттелит хаба device, контекст абонентского оборудования)
DROP TABLE IF EXISTS sperfilyev.dds_t_sat_device CASCADE;
CREATE TABLE sperfilyev.dds_t_sat_device
(
    device_pk       TEXT,
    device_hashdiff TEXT,
    device_ip_addr  TEXT,
    effective_from  DATE,
    load_dts        TIMESTAMP,
    rec_source      TEXT
) DISTRIBUTED RANDOMLY;
