-- Тестируем заполнение слоя DDS данными за из ODS

-- Очистить все хэши в ODS
TRUNCATE sperfilyev.ods_t_billing_hashed;
TRUNCATE sperfilyev.ods_t_issue_hashed;
TRUNCATE sperfilyev.ods_t_payment_hashed;
TRUNCATE sperfilyev.ods_t_traffic_hashed;
TRUNCATE sperfilyev.ods_t_user_hashed;

-- Рассчитаем хэши для всех источников

-- Расчёт хэшей. Источник MDM user. Загрузить всё
INSERT INTO sperfilyev.ods_t_user_hashed (
    SELECT v.*,
           current_timestamp AS load_dts
    FROM sperfilyev.ods_v_user_etl AS v);

-- Проверка
select count(*),
       count(distinct user_pk),
       count(distinct user_key),
       count(distinct user_hashdiff)
from sperfilyev.ods_t_user_hashed;

select * from sperfilyev.ods_t_user_hashed order by user_key;

-- Расчёт хэшей. Источник billing. Загрузить всё
INSERT INTO sperfilyev.ods_t_billing_hashed (
    SELECT v.*,
           current_timestamp AS load_dts
    FROM sperfilyev.ods_v_billing_etl AS v);

-- Расчёт хэшей. Источник billing. Загрузить один год
insert into sperfilyev.ods_t_billing_hashed
select v.*,
       '2013-01-01'::date as load_dts
from sperfilyev.ods_v_billing_etl as v
where extract(year from effective_from)=2013;

-- Проверка
select count(*),
       count(distinct billing_pk),
       count(distinct user_pk),
       count(distinct billing_period_pk),
       count(distinct service_pk),
       count(distinct tariff_pk),
       min(billing_sum), max(billing_sum), avg(billing_sum), sum(billing_sum),
       min(effective_from), max(effective_from)
from sperfilyev.ods_t_billing_hashed;

select * from sperfilyev.ods_t_billing_hashed order by user_key, effective_from;
select * from sperfilyev.ods_t_billing_hashed order by effective_from desc limit 10;

select extract(year from effective_from) as billing_year, count(*)
from sperfilyev.ods_t_billing_hashed
group by billing_year
order by billing_year;

select load_dts, count(*)
from sperfilyev.ods_t_billing_hashed
group by load_dts
order by load_dts;

-- Расчёт хэшей. Источник issue. Загрузить всё
INSERT INTO sperfilyev.ods_t_issue_hashed (
    SELECT v.*,
           current_timestamp AS load_dts
    FROM sperfilyev.ods_v_issue_etl AS v);

-- Расчёт хэшей. Источник issue. Загрузить один год
insert into sperfilyev.ods_t_issue_hashed
select v.*,
       '2013-01-01'::date as load_dts
from sperfilyev.ods_v_issue_etl as v
where extract(year from effective_from)=2013;

-- Проверка
select count(*),
       count(distinct issue_pk),
       count(distinct user_pk),
       count(distinct service_pk),
       count(distinct issue_hashdiff),
       min(effective_from), max(effective_from),
       min(end_time), max(end_time)
from sperfilyev.ods_t_issue_hashed;

select * from sperfilyev.ods_t_issue_hashed order by user_key, effective_from;
select * from sperfilyev.ods_t_issue_hashed order by effective_from desc limit 10;

select extract(year from effective_from) as issue_year, count(*)
from sperfilyev.ods_t_issue_hashed
group by issue_year
order by issue_year;

select load_dts, count(*)
from sperfilyev.ods_t_issue_hashed
group by load_dts
order by load_dts;

-- Расчёт хэшей. Источник payment. Загрузить всё
INSERT INTO sperfilyev.ods_t_payment_hashed (
    SELECT v.*,
           current_timestamp AS load_dts
    FROM sperfilyev.ods_v_payment_etl AS v);

-- Расчёт хэшей. Источник payment. Загрузить один год
insert into sperfilyev.ods_t_payment_hashed
select v.*,
       '2013-01-01'::date as load_dts
from sperfilyev.ods_v_payment_etl as v
where extract(year from effective_from)=2013;

-- Проверка
select count(*),
       count(distinct payment_pk),
       count(distinct user_pk),
       count(distinct billing_period_pk),
       count(distinct account_pk),
       count(distinct paysys_pk),
       min(effective_from), max(effective_from),
       sum(pay_sum)
from sperfilyev.ods_t_payment_hashed;

select * from sperfilyev.ods_t_payment_hashed order by user_key, effective_from;
select * from sperfilyev.ods_t_payment_hashed order by effective_from desc limit 10;

select extract(year from effective_from) as pay_year, count(*)
from sperfilyev.ods_t_payment_hashed
group by pay_year
order by pay_year;

select load_dts, count(*)
from sperfilyev.ods_t_payment_hashed
group by load_dts
order by load_dts;

-- Расчёт хэшей. Источник traffic. Загрузить всё
INSERT INTO sperfilyev.ods_t_traffic_hashed (
    SELECT v.*,
           current_timestamp AS load_dts
    FROM sperfilyev.ods_v_traffic_etl AS v);

-- Расчёт хэшей. Источник payment. Загрузить один год
insert into sperfilyev.ods_t_traffic_hashed
select v.*,
       '2013-01-01'::date as load_dts
from sperfilyev.ods_v_traffic_etl as v
where extract(year from effective_from)=2013;

-- Проверка
select count(*),
       count(distinct user_pk),
       count(distinct device_pk),
       count(distinct traffic_pk),
       count(distinct traffic_hashdiff),
       count(distinct device_hashdiff),
       min(bytes_sent), max(bytes_sent), sum(bytes_sent),
       min(bytes_received), max(bytes_received), sum(bytes_received),
       min(effective_from), max(effective_from)
from sperfilyev.ods_t_traffic_hashed;

select * from sperfilyev.ods_t_traffic_hashed order by user_key, effective_from;
select * from sperfilyev.ods_t_traffic_hashed order by effective_from desc limit 10;

select extract(year from effective_from) as pay_year, count(*)
from sperfilyev.ods_t_traffic_hashed
group by pay_year
order by pay_year;

select load_dts, count(*)
from sperfilyev.ods_t_traffic_hashed
group by load_dts
order by load_dts;

-- ===============================================================
-- Очистить все хабы
truncate sperfilyev.dds_t_hub_user;
truncate sperfilyev.dds_t_hub_account;
truncate sperfilyev.dds_t_hub_billing_period;
truncate sperfilyev.dds_t_hub_paysys;
truncate sperfilyev.dds_t_hub_service;
truncate sperfilyev.dds_t_hub_tariff;
truncate sperfilyev.dds_t_hub_device;

-- ===========================================
-- Hub user. Загрузка данных из ODS user (MDM)
INSERT INTO sperfilyev.dds_t_hub_user SELECT * FROM sperfilyev.dds_v_hub_user_mdm_etl;
-- Проверка. Должны выбраться все абоненты
select count(*) from sperfilyev.dds_t_hub_user;
select count(distinct user_pk) from sperfilyev.dds_t_hub_user;
select count(*), load_dts from sperfilyev.dds_t_hub_user group by load_dts order by load_dts desc;
-- Проверка ещё раз. Теперь не должно быть записей для добавления
select count(*) from sperfilyev.dds_v_hub_user_mdm_etl;

-- Hub user. Загрузка данных из ODS payment
INSERT INTO sperfilyev.dds_t_hub_user SELECT * FROM sperfilyev.dds_v_hub_user_payment_etl;
-- Проверка. Должны выбраться все абоненты
select count(*) from sperfilyev.dds_t_hub_user;
select count(distinct user_pk) from sperfilyev.dds_t_hub_user;
select count(*), load_dts from sperfilyev.dds_t_hub_user group by load_dts order by load_dts desc;
-- Проверка ещё раз. Теперь не должно быть записей для добавления
select count(*) from sperfilyev.dds_v_hub_user_payment_etl;

-- Hub account. Загрузка данных из ODS payment
INSERT INTO sperfilyev.dds_t_hub_account SELECT * FROM sperfilyev.dds_v_hub_account_etl;
-- Проверка. Должны выбраться все счета
select count(*) from sperfilyev.dds_t_hub_account;
select count(distinct account_pk) from sperfilyev.dds_t_hub_account;
select count(*), load_dts from sperfilyev.dds_t_hub_account group by load_dts order by load_dts desc;
-- Проверка ещё раз. Теперь не должно быть записей для добавления
select count(*) from sperfilyev.dds_v_hub_account_etl;

-- Hub billing_period. Загрузка данных из ODS payment
INSERT INTO sperfilyev.dds_t_hub_billing_period SELECT * FROM sperfilyev.dds_v_hub_billing_period_etl;
-- Проверка. Должны выбраться все расчётные периоды
select count(*) from sperfilyev.dds_t_hub_billing_period;
select count(distinct billing_period_pk) from sperfilyev.dds_t_hub_billing_period;
select count(*), load_dts from sperfilyev.dds_t_hub_billing_period group by load_dts order by load_dts desc;
-- Проверка ещё раз. Теперь не должно быть записей для добавления
select count(*) from sperfilyev.dds_v_hub_billing_period_etl;

-- Hub paysys. Загрузка данных из ODS payment
INSERT INTO sperfilyev.dds_t_hub_paysys SELECT * FROM sperfilyev.dds_v_hub_paysys_etl;
-- Проверка. Должны выбраться все платёжные системы
select count(*) from sperfilyev.dds_t_hub_paysys;
select distinct paysys_pk from sperfilyev.dds_t_hub_paysys;
select distinct paysys_key from sperfilyev.dds_t_hub_paysys;
select count(*), load_dts from sperfilyev.dds_t_hub_paysys group by load_dts order by load_dts desc;
-- Проверка ещё раз. Теперь не должно быть записей для добавления
select count(*) from sperfilyev.dds_v_hub_paysys_etl;

-- Hub service. Загрузка данных из ODS issue
INSERT INTO sperfilyev.dds_t_hub_service SELECT * FROM sperfilyev.dds_v_hub_service_issue_etl;
-- Проверка. Должны выбраться все услуги
select count(*) from sperfilyev.dds_t_hub_service;
select distinct service_pk from sperfilyev.dds_t_hub_service;
select distinct service_key from sperfilyev.dds_t_hub_service;
select count(*), load_dts from sperfilyev.dds_t_hub_service group by load_dts order by load_dts desc;
-- Проверка ещё раз. Теперь не должно быть записей для добавления
select count(*) from sperfilyev.dds_v_hub_service_issue_etl;

-- Hub service. Загрузка данных из ODS billing
INSERT INTO sperfilyev.dds_t_hub_service SELECT * FROM sperfilyev.dds_v_hub_service_billing_etl;
-- Проверка. Должны выбраться все услуги
select count(*) from sperfilyev.dds_t_hub_service;
select distinct service_pk from sperfilyev.dds_t_hub_service;
select distinct service_key from sperfilyev.dds_t_hub_service;
select count(*), load_dts from sperfilyev.dds_t_hub_service group by load_dts order by load_dts desc;
-- Проверка ещё раз. Теперь не должно быть записей для добавления
select count(*) from sperfilyev.dds_v_hub_service_billing_etl;

-- Hub tariff. Загрузка данных из ODS billing
INSERT INTO sperfilyev.dds_t_hub_tariff SELECT * FROM sperfilyev.dds_v_hub_tariff_etl;
-- Проверка. Должны выбраться все тарифы
select count(*) from sperfilyev.dds_t_hub_tariff;
select distinct tariff_pk from sperfilyev.dds_t_hub_tariff;
select distinct tariff_key from sperfilyev.dds_t_hub_tariff;
select count(*), load_dts from sperfilyev.dds_t_hub_tariff group by load_dts order by load_dts desc;
-- Проверка ещё раз. Теперь не должно быть записей для добавления
select count(*) from sperfilyev.dds_v_hub_tariff_etl;

-- Hub device. Загрузка данных из ODS traffic
INSERT INTO sperfilyev.dds_t_hub_device SELECT * FROM sperfilyev.dds_v_hub_device_etl;
-- Проверка. Должны выбраться все абонентские устройства
select count(*) from sperfilyev.dds_t_hub_device;
select count(distinct device_pk), count(distinct device_key) from sperfilyev.dds_t_hub_device;
select count(*), load_dts from sperfilyev.dds_t_hub_device group by load_dts order by load_dts desc;
-- Проверка ещё раз. Теперь не должно быть записей для добавления
select count(*) from sperfilyev.dds_v_hub_device_etl;

-- ===========================================
-- Очистить все линки
truncate sperfilyev.dds_t_lnk_payment;
truncate sperfilyev.dds_t_lnk_issue;
truncate sperfilyev.dds_t_lnk_billing;
truncate sperfilyev.dds_t_lnk_traffic;

-- Link payment
INSERT INTO sperfilyev.dds_t_lnk_payment SELECT * FROM sperfilyev.dds_v_lnk_payment_etl;
-- Проверка. Должны выбраться все платежи
select count(*) from sperfilyev.dds_t_lnk_payment;
select count(distinct payment_pk),
       count(distinct user_pk),
       count(distinct billing_period_pk),
       count(distinct account_pk),
       count(distinct paysys_pk),
       min(effective_from), max(effective_from)
from sperfilyev.dds_t_lnk_payment;
select count(*), load_dts from sperfilyev.dds_t_lnk_payment group by load_dts order by load_dts desc;
-- Проверка ещё раз. Теперь не должно быть записей для добавления
select count(*) from sperfilyev.dds_v_lnk_payment_etl;

-- Link issue
INSERT INTO sperfilyev.dds_t_lnk_issue SELECT * FROM sperfilyev.dds_v_lnk_issue_etl;
-- Проверка. Должны выбраться все обращения
select count(*) from sperfilyev.dds_t_lnk_issue;
select count(distinct issue_pk),
       count(distinct user_pk),
       count(distinct service_pk),
       min(effective_from), max(effective_from)
from sperfilyev.dds_t_lnk_issue;
select count(*), load_dts from sperfilyev.dds_t_lnk_issue group by load_dts order by load_dts desc;
-- Проверка ещё раз. Теперь не должно быть записей для добавления
select count(*) from sperfilyev.dds_v_lnk_issue_etl;

-- Link billing
INSERT INTO sperfilyev.dds_t_lnk_billing SELECT * FROM sperfilyev.dds_v_lnk_billing_etl;
-- Проверка. Должны выбраться все начисления
select count(*) from sperfilyev.dds_t_lnk_billing;
select count(distinct billing_pk),
       count(distinct user_pk),
       count(distinct billing_period_pk),
       count(distinct service_pk),
       count(distinct tariff_pk),
       min(effective_from), max(effective_from)
from sperfilyev.dds_t_lnk_billing;
select count(*), load_dts from sperfilyev.dds_t_lnk_billing group by load_dts order by load_dts desc;
-- Проверка ещё раз. Теперь не должно быть записей для добавления
select count(*) from sperfilyev.dds_v_lnk_billing_etl;

-- Link traffic
INSERT INTO sperfilyev.dds_t_lnk_traffic SELECT * FROM sperfilyev.dds_v_lnk_traffic_etl;
-- Проверка. Должны выбраться все сессий передачи данных
select count(*) from sperfilyev.dds_t_lnk_traffic;
select count(distinct traffic_pk),
       count(distinct user_pk),
       count(distinct device_pk),
       min(effective_from), max(effective_from)
from sperfilyev.dds_t_lnk_traffic;
select count(*), load_dts from sperfilyev.dds_t_lnk_traffic group by load_dts order by load_dts desc;
-- Проверка ещё раз. Теперь не должно быть записей для добавления
select count(*) from sperfilyev.dds_v_lnk_traffic_etl;

-- ===========================================
-- Очистить все сателлиты
truncate sperfilyev.dds_t_sat_user_mdm;
truncate sperfilyev.dds_t_sat_user;
truncate sperfilyev.dds_t_sat_payment;
truncate sperfilyev.dds_t_sat_issue;
truncate sperfilyev.dds_t_sat_billing;
truncate sperfilyev.dds_t_sat_traffic;
truncate sperfilyev.dds_t_sat_device;

-- Sat user_mdm. Загрузка данных из ODS user (MDM)
INSERT INTO sperfilyev.dds_t_sat_user_mdm SELECT * FROM sperfilyev.dds_v_sat_user_mdm_etl;
-- Проверка
select count(*) from sperfilyev.dds_t_sat_user_mdm;
select * from sperfilyev.dds_t_sat_user_mdm;
select load_dts, count(*) from sperfilyev.dds_t_sat_user_mdm group by load_dts order by load_dts desc;
-- Проверка ещё раз. Теперь не должно быть записей для добавления
select count(*) from sperfilyev.dds_v_sat_user_mdm_etl;
-- Проверим как данные из сателлита стыкуются с хабом
drop view if exists sperfilyev.dds_v_user_detailed;
create view sperfilyev.dds_v_user_detailed as (
select h.user_pk as hub_pk,
       h.user_key as user_id,
       h.load_dts as hub_loaddts,
       h.rec_source as hub_recsrc,
       s.*
from sperfilyev.dds_t_hub_user h
join sperfilyev.dds_t_sat_user_mdm s
on h.user_pk=s.user_pk);
-- Ну что?
select * from sperfilyev.dds_v_user_detailed order by user_id;
select count(*), count(distinct hub_pk)  from sperfilyev.dds_v_user_detailed;
drop view sperfilyev.dds_v_user_detailed;

-- ======================================================
-- Проверим как подгрузились сателлиты в Airflow по годам
-- Сателлиты хабов
select load_dts, count(*) from sperfilyev.dds_t_sat_user group by load_dts order by load_dts desc;
select load_dts, count(*) from sperfilyev.dds_t_sat_device group by load_dts order by load_dts desc;
select * from sperfilyev.dds_t_sat_user;
select * from sperfilyev.dds_t_sat_device;

-- Сателлиты линков
select load_dts, count(*) from sperfilyev.dds_t_sat_payment group by load_dts order by load_dts desc;
select load_dts, count(*) from sperfilyev.dds_t_sat_issue group by load_dts order by load_dts desc;
select load_dts, count(*) from sperfilyev.dds_t_sat_billing group by load_dts order by load_dts desc;
select load_dts, count(*) from sperfilyev.dds_t_sat_traffic group by load_dts order by load_dts desc;
select count(*) from sperfilyev.dds_t_sat_payment;
select count(*) from sperfilyev.dds_t_sat_issue;
select count(*) from sperfilyev.dds_t_sat_billing;
select count(*) from sperfilyev.dds_t_sat_traffic;

-- Вычислим агрегаты по фактам (сателлитам линков)
select sum(pay_sum) from sperfilyev.dds_t_sat_payment;
select sum(billing_sum) from sperfilyev.dds_t_sat_billing;
select count(*) from sperfilyev.dds_t_sat_issue;
select sum(cast(bytes_sent as bigint)+cast(bytes_received as bigint)) from sperfilyev.dds_t_sat_traffic;
