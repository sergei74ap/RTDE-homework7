-- ВАЖНО: ПРИ АВТОМАТИЗАЦИИ СБОРКИ ВИТРИНЫ В AIRFLOW НУЖНО ЗАПУСКАТЬ DAG НАЧИНАЯ С 2012 ГОДА!!!
-- ПОТОМУ ЧТО ЕСТЬ ЗАПИСИ С billing_period=2012 (ПРОВЕРКИ ПРИВЕДЕНЫ НИЖЕ, ВЫЯВЛЕНЫ РАСХОЖДЕНИЯ ПРИ ЗАПУСКЕ С 2013)

-- Таблицы измерений
CREATE TABLE sperfilyev.dm_report_dim_report_year(
    id SERIAL PRIMARY KEY, report_year_key INT);
CREATE TABLE sperfilyev.dm_report_dim_legal_type(
    id SERIAL PRIMARY KEY, legal_type_key TEXT);
CREATE TABLE sperfilyev.dm_report_dim_district(
    id SERIAL PRIMARY KEY, district_key TEXT);
CREATE TABLE sperfilyev.dm_report_dim_billing_mode(
    id SERIAL PRIMARY KEY, billing_mode_key TEXT);
CREATE TABLE sperfilyev.dm_report_dim_registration_year(
    id SERIAL PRIMARY KEY, registration_year_key INT);

-- Таблица фактов
drop table sperfilyev.dm_report_fct;
CREATE TABLE sperfilyev.dm_report_fct(
    report_year_id INT,
    legal_type_id INT,
    district_id INT,
    billing_mode_id INT,
    registration_year_id INT,
    is_vip BOOLEAN,
    payment_sum NUMERIC(10, 2),
    billing_sum NUMERIC(10, 2),
    issue_cnt INT,
    traffic_amount BIGINT,
    CONSTRAINT fk_report_year FOREIGN KEY(report_year_id)
        REFERENCES sperfilyev.dm_report_dim_report_year(id),
    CONSTRAINT fk_legal_type FOREIGN KEY(legal_type_id)
        REFERENCES sperfilyev.dm_report_dim_legal_type(id),
    CONSTRAINT fk_district FOREIGN KEY(district_id)
        REFERENCES sperfilyev.dm_report_dim_district(id),
    CONSTRAINT fk_billing_mode FOREIGN KEY(billing_mode_id)
        REFERENCES sperfilyev.dm_report_dim_billing_mode(id),
    CONSTRAINT fk_registration_year FOREIGN KEY(registration_year_id)
        REFERENCES sperfilyev.dm_report_dim_registration_year(id)
    );

-- ===========================================
-- Собрать временные денормализованные таблицы

-- Временная таблица. Payment
DROP TABLE IF EXISTS sperfilyev.dm_report_payment_tmp;
CREATE TABLE sperfilyev.dm_report_payment_tmp AS (
  WITH raw_data AS (
      SELECT legal_type,
             district,
             billing_mode,
             EXTRACT(YEAR FROM su.effective_from) as registration_year,
             is_vip,
             pay_sum,
             billing_period_key,
             EXTRACT(YEAR FROM to_date(billing_period_key, 'YYYY-MM')) AS report_year
      FROM sperfilyev.dds_t_lnk_payment l
      JOIN sperfilyev.dds_t_hub_billing_period hbp ON l.billing_period_pk=hbp.billing_period_pk
      JOIN sperfilyev.dds_t_hub_user hu ON l.user_pk=hu.user_pk
      JOIN sperfilyev.dds_t_sat_payment s ON l.payment_pk=s.payment_pk
      LEFT JOIN sperfilyev.dds_t_sat_user_mdm su ON hu.user_pk=su.user_pk),
  oneyear_data AS (
      SELECT * FROM raw_data
      WHERE report_year>=2000
  )
SELECT report_year, legal_type, district, billing_mode, registration_year,
       is_vip, sum(pay_sum) as payment_sum
FROM oneyear_data
GROUP BY report_year, legal_type, district, billing_mode, registration_year, is_vip
ORDER BY report_year, legal_type, district, billing_mode, registration_year, is_vip
);

-- Проверка наполнения временной таблицы
select count(*) from sperfilyev.dm_report_payment_tmp;
select * from sperfilyev.dm_report_payment_tmp
order by report_year, legal_type, district, billing_mode, registration_year, is_vip;
-- Контроль по суммам
select sum(payment_sum) from sperfilyev.dm_report_payment_tmp;
select sum(pay_sum) from sperfilyev.dds_t_sat_payment;

-- Временная таблица. Billing
DROP TABLE IF EXISTS sperfilyev.dm_report_billing_tmp;
CREATE TABLE sperfilyev.dm_report_billing_tmp AS (
  WITH raw_data AS (
      SELECT legal_type,
             district,
             billing_mode,
             EXTRACT(YEAR FROM su.effective_from) as registration_year,
             is_vip,
             billing_sum,
             billing_period_key,
             EXTRACT(YEAR FROM to_date(billing_period_key, 'YYYY-MM')) AS report_year
      FROM sperfilyev.dds_t_lnk_billing l
      JOIN sperfilyev.dds_t_hub_billing_period hbp ON l.billing_period_pk=hbp.billing_period_pk
      JOIN sperfilyev.dds_t_hub_user hu ON l.user_pk=hu.user_pk
      JOIN sperfilyev.dds_t_sat_billing s ON l.billing_pk=s.billing_pk
      LEFT JOIN sperfilyev.dds_t_sat_user_mdm su ON hu.user_pk=su.user_pk),
  oneyear_data AS (
      SELECT * FROM raw_data
      WHERE report_year>=2000
  )
SELECT report_year, legal_type, district, billing_mode, registration_year,
       is_vip, sum(billing_sum) as billing_sum
FROM oneyear_data
GROUP BY report_year, legal_type, district, billing_mode, registration_year, is_vip
ORDER BY report_year, legal_type, district, billing_mode, registration_year, is_vip
);

-- Проверка наполнения временной таблицы
select count(*) from sperfilyev.dm_report_billing_tmp;
select * from sperfilyev.dm_report_billing_tmp
order by report_year, legal_type, district, billing_mode, registration_year, is_vip;
-- Контроль по суммам
select sum(billing_sum) from sperfilyev.dm_report_billing_tmp;
select sum(billing_sum) from sperfilyev.dds_t_sat_billing;

-- Временная таблица. Issue
DROP TABLE IF EXISTS sperfilyev.dm_report_issue_tmp;
CREATE TABLE sperfilyev.dm_report_issue_tmp AS (
  WITH raw_data AS (
      SELECT legal_type,
             district,
             billing_mode,
             EXTRACT(YEAR FROM su.effective_from) as registration_year,
             is_vip,
             l.issue_pk AS issue_pk,
             EXTRACT(YEAR FROM l.effective_from) AS report_year
      FROM sperfilyev.dds_t_lnk_issue l
      JOIN sperfilyev.dds_t_hub_user hu ON l.user_pk=hu.user_pk
      JOIN sperfilyev.dds_t_sat_issue s ON l.issue_pk=s.issue_pk
      LEFT JOIN sperfilyev.dds_t_sat_user_mdm su ON hu.user_pk=su.user_pk),
  oneyear_data AS (
      SELECT * FROM raw_data
      WHERE report_year>=2000
  )
SELECT report_year, legal_type, district, billing_mode, registration_year,
       is_vip, count(issue_pk) as issue_cnt
FROM oneyear_data
GROUP BY report_year, legal_type, district, billing_mode, registration_year, is_vip
ORDER BY report_year, legal_type, district, billing_mode, registration_year, is_vip
);

-- Проверка наполнения временной таблицы
select count(*) from sperfilyev.dm_report_issue_tmp;
select * from sperfilyev.dm_report_issue_tmp
order by report_year, legal_type, district, billing_mode, registration_year, is_vip;
-- Контроль по суммам
select sum(issue_cnt) from sperfilyev.dm_report_issue_tmp;

-- Временная таблица. Traffic
DROP TABLE IF EXISTS sperfilyev.dm_report_traffic_tmp;
CREATE TABLE sperfilyev.dm_report_traffic_tmp AS (
  WITH raw_data AS (
      SELECT legal_type,
             district,
             billing_mode,
             EXTRACT(YEAR FROM su.effective_from) AS registration_year,
             is_vip,
             bytes_sent, bytes_received,
             EXTRACT(YEAR FROM l.effective_from) AS report_year
      FROM sperfilyev.dds_t_lnk_traffic l
      JOIN sperfilyev.dds_t_hub_user hu ON l.user_pk=hu.user_pk
      JOIN sperfilyev.dds_t_sat_traffic s ON l.traffic_pk=s.traffic_pk
      LEFT JOIN sperfilyev.dds_t_sat_user_mdm su ON hu.user_pk=su.user_pk),
  oneyear_data AS (
      SELECT * FROM raw_data
      WHERE report_year>=2000
  )
SELECT report_year, legal_type, district, billing_mode, registration_year,
       is_vip,
       sum(cast(bytes_sent AS BIGINT) + cast(bytes_received AS BIGINT)) AS traffic_amount
FROM oneyear_data
GROUP BY report_year, legal_type, district, billing_mode, registration_year, is_vip
ORDER BY report_year, legal_type, district, billing_mode, registration_year, is_vip
);
-- Проверка наполнения временной таблицы
select count(*) from sperfilyev.dm_report_traffic_tmp;
select * from sperfilyev.dm_report_traffic_tmp
order by report_year, legal_type, district, billing_mode, registration_year, is_vip;
-- Контроль по суммам
select sum(traffic_amount) from sperfilyev.dm_report_traffic_tmp;
select sum(cast(bytes_sent as bigint)+cast(bytes_received as bigint)) from sperfilyev.dds_t_sat_traffic;

-- ======================================================================
-- Наполнить таблицы измерений данными из временных таблиц
INSERT INTO sperfilyev.dm_report_dim_report_year(report_year_key)
SELECT DISTINCT report_year AS billing_year_key
FROM sperfilyev.dm_report_payment_tmp
LEFT JOIN sperfilyev.dm_report_dim_report_year ON report_year_key=report_year
WHERE report_year_key is NULL;

INSERT INTO sperfilyev.dm_report_dim_legal_type(legal_type_key)
SELECT DISTINCT legal_type AS legal_type_key
FROM sperfilyev.dm_report_payment_tmp
LEFT JOIN sperfilyev.dm_report_dim_legal_type ON legal_type_key=legal_type
WHERE legal_type_key is NULL;

INSERT INTO sperfilyev.dm_report_dim_district(district_key)
SELECT DISTINCT district AS district_key
FROM sperfilyev.dm_report_payment_tmp
LEFT JOIN sperfilyev.dm_report_dim_district ON district_key=district
WHERE district_key is NULL;

INSERT INTO sperfilyev.dm_report_dim_billing_mode(billing_mode_key)
SELECT DISTINCT billing_mode AS billing_mode_key
FROM sperfilyev.dm_report_payment_tmp
LEFT JOIN sperfilyev.dm_report_dim_billing_mode ON billing_mode_key=billing_mode
WHERE dm_report_dim_billing_mode.billing_mode_key is NULL;

INSERT INTO sperfilyev.dm_report_dim_registration_year(registration_year_key)
SELECT DISTINCT registration_year AS registration_year_key
FROM sperfilyev.dm_report_payment_tmp
LEFT JOIN sperfilyev.dm_report_dim_registration_year ON registration_year_key=registration_year
WHERE registration_year_key is NULL;


select EXTRACT(YEAR FROM to_date(billing_period_key, 'YYYY-MM')) AS report_year
from sperfilyev.dds_t_lnk_payment;


-- Проверка наполнения таблиц измерений
select count(*) from sperfilyev.dm_report_dim_report_year
select * from sperfilyev.dm_report_dim_report_year order by id;

select count(*) from sperfilyev.dm_report_dim_legal_type;
select * from sperfilyev.dm_report_dim_legal_type order by id;

select count(*) from sperfilyev.dm_report_dim_district;
select * from sperfilyev.dm_report_dim_district order by id;

select count(*) from sperfilyev.dm_report_dim_billing_mode;
select * from sperfilyev.dm_report_dim_billing_mode order by id;

select count(*) from sperfilyev.dm_report_dim_registration_year;
select * from sperfilyev.dm_report_dim_registration_year order by id;

-- ===============================================================
-- Наполнить данными таблицу фактов, собрать из временных таблиц
INSERT INTO sperfilyev.dm_report_fct
SELECT y.id, lt.id, d.id, bm.id, ry.id, pay.is_vip,
       pay.payment_sum, bill.billing_sum, issue_cnt, traffic_amount
FROM sperfilyev.dm_report_payment_tmp pay
JOIN sperfilyev.dm_report_dim_report_year y ON pay.report_year=y.report_year_key
JOIN sperfilyev.dm_report_dim_legal_type lt ON pay.legal_type=lt.legal_type_key
JOIN sperfilyev.dm_report_dim_district d ON pay.district=d.district_key
JOIN sperfilyev.dm_report_dim_billing_mode bm ON pay.billing_mode=bm.billing_mode_key
JOIN sperfilyev.dm_report_dim_registration_year ry ON pay.registration_year=ry.registration_year_key
--
LEFT JOIN sperfilyev.dm_report_billing_tmp bill
    ON bill.report_year=y.report_year_key
           AND bill.legal_type=lt.legal_type_key
           AND bill.district=d.district_key
           AND bill.billing_mode=bm.billing_mode_key
           AND bill.registration_year=ry.registration_year_key
           AND bill.is_vip=pay.is_vip
--
LEFT JOIN sperfilyev.dm_report_issue_tmp issue
    ON issue.report_year=y.report_year_key
           AND issue.legal_type=lt.legal_type_key
           AND issue.district=d.district_key
           AND issue.billing_mode=bm.billing_mode_key
           AND issue.registration_year=ry.registration_year_key
           AND issue.is_vip=pay.is_vip
--
LEFT JOIN sperfilyev.dm_report_traffic_tmp trf
    ON trf.report_year=y.report_year_key
           AND trf.legal_type=lt.legal_type_key
           AND trf.district=d.district_key
           AND trf.billing_mode=bm.billing_mode_key
           AND trf.registration_year=ry.registration_year_key
           AND trf.is_vip=pay.is_vip;

UPDATE sperfilyev.dm_report_fct SET issue_cnt=0 WHERE issue_cnt IS NULL;
UPDATE sperfilyev.dm_report_fct SET traffic_amount=0 WHERE traffic_amount IS NULL;

-- Проверка наполнения таблицы фактов
select count(*) from sperfilyev.dm_report_fct;
select * from sperfilyev.dm_report_fct;
-- Сравним общую сумму платежей с первоисточником в ODS:
select sum(payment_sum) from sperfilyev.dm_report_fct;
select count(*) from sperfilyev.ods_t_payment;
select sum(pay_sum) from sperfilyev.ods_t_payment;
-- сумма = 49,642,723
-- Сравним общую сумму начислений с первоисточником в ODS:
select sum(billing_sum) from sperfilyev.dm_report_fct;
select count(*) from sperfilyev.ods_t_billing;
select sum(billing_sum) from sperfilyev.ods_t_billing;
-- сумма = 49,642,723
-- Сравним общее кол-во обращений с данными ODS:
select sum(issue_cnt) from sperfilyev.dm_report_fct;
select count(distinct issue_pk) from sperfilyev.dds_t_lnk_issue;
-- кол-во должно быть = 10,000
-- Сравним общий объём трафика с данными в DDS:
select sum(traffic_amount) from sperfilyev.dm_report_fct;
select sum(cast(bytes_sent as bigint)+cast(bytes_received as bigint)) from sperfilyev.dds_t_sat_traffic;
-- Сумма=21,359,910,962,873

-- ======================================================
-- Очистить временные таблицы
truncate sperfilyev.dm_report_payment_tmp;
truncate sperfilyev.dm_report_billing_tmp;
truncate sperfilyev.dm_report_issue_tmp;
truncate sperfilyev.dm_report_traffic_tmp;

-- Очистить витрину
truncate sperfilyev.dm_report_fct;

-- Очистить измерения
truncate sperfilyev.dm_report_dim_report_year;
truncate sperfilyev.dm_report_dim_legal_type;
truncate sperfilyev.dm_report_dim_district;
truncate sperfilyev.dm_report_dim_billing_mode;
truncate sperfilyev.dm_report_dim_registration_year;

-- =====================================================
-- Проверим причины расхождений агрегатов по DDS и по DM
-- Гипотеза: выпадают порции данных ранее 2013 года?
with raw_data as (
    SELECT pay_sum,
           billing_period_key,
           EXTRACT(YEAR FROM to_date(billing_period_key, 'YYYY-MM')) AS report_year
    FROM sperfilyev.dds_t_lnk_payment l
             JOIN sperfilyev.dds_t_hub_billing_period hbp ON l.billing_period_pk = hbp.billing_period_pk
             JOIN sperfilyev.dds_t_sat_payment s ON l.payment_pk = s.payment_pk
)
SELECT sum(pay_sum) FROM raw_data
WHERE report_year=2012;

with raw_data as (
    SELECT billing_sum,
           billing_period_key,
           EXTRACT(YEAR FROM to_date(billing_period_key, 'YYYY-MM')) AS report_year
    FROM sperfilyev.dds_t_lnk_billing l
             JOIN sperfilyev.dds_t_hub_billing_period hbp ON l.billing_period_pk = hbp.billing_period_pk
             JOIN sperfilyev.dds_t_sat_billing s ON l.billing_pk = l.billing_pk
)
SELECT sum(billing_sum) FROM raw_data
WHERE report_year=2012;

select sum(pay_sum) from ods_t_payment where EXTRACT(YEAR FROM to_date(billing_period, 'YYYY-MM'))=2012;
select sum(billing_sum) from ods_t_billing where EXTRACT(YEAR FROM to_date(billing_period, 'YYYY-MM'))=2012;
select billing_period_key from sperfilyev.dds_t_hub_billing_period order by billing_period_key;
-- Вывод: для payment и billing - гипотеза верная. Есть данные с billing_period = 2012

-- А для issue?
select count(*) from ods_t_issue where EXTRACT(YEAR FROM start_time)<2013;
select count(*) from stg_v_issue where EXTRACT(YEAR FROM start_time)<2013;
select distinct EXTRACT(YEAR FROM start_time) as start_year from ods_t_issue order by start_year;
select distinct EXTRACT(YEAR FROM cast(start_time as date)) as start_year from stg_t_issue order by start_year;
-- Нет

-- А для traffic?
select sum(bytes_sent), sum(bytes_received) from ods_t_traffic where EXTRACT(YEAR FROM traffic_time)<2013;
select sum(bytes_sent), sum(bytes_received) from stg_v_traffic where EXTRACT(YEAR FROM traffic_time)<2013;
-- Нет

-- ВЫВОД: ПРИ АВТОМАТИЗАЦИИ СБОРКИ ВИТРИНЫ В AIRFLOW НУЖНО ЗАПУСКАТЬ DAG НАЧИНАЯ С 2012 ГОДА!!!
