-- ====================================================
-- Создаём слой STG DWH
-- Для DWH в качестве слоя STG будем использовать ранее подготовленный ODS Data Lake.
-- Таблицы STG DWH будут находиться в Google Cloud Storage (внешние по отношению к Greenplum)
drop external table if exists sperfilyev.stg_t_payment;
create external table sperfilyev.stg_t_payment (
    user_id int,
    pay_doc_type text,
    pay_doc_num int,
    account text,
    phone text,
    billing_period text,
    pay_date date,
    "sum" decimal(10, 2)
    )
    location (
        'pxf://rt-2021-03-25-16-47-29-sfunu-sperfilyev/data_lake/ods/payment/*/?PROFILE=gs:parquet'
        )
    format 'CUSTOM' (
        FORMATTER = 'pxfwritable_import'
        );

-- Проверки
select * from sperfilyev.stg_t_payment limit 100;
select count(*) from sperfilyev.stg_t_payment;

select distinct extract(month from pay_date) as pay_month,
                extract(year from pay_date) as pay_year
from sperfilyev.stg_t_payment
order by pay_year, pay_month;

-- ====================================================
-- Создаём слой ODS DWH
drop table if exists sperfilyev.ods_t_payment cascade;
create table sperfilyev.ods_t_payment
(
    user_id        int,
    pay_doc_type   text,
    pay_doc_num    int,
    account        text,
    phone          text,
    billing_period text,
    pay_date       date,
    pay_sum        decimal(10, 2)
)
distributed randomly;

-- ====================================================
-- Для источника payments подготовим вьюшку со всеми ключами и хэшами
drop view if exists sperfilyev.ods_v_payment_etl cascade;
create view sperfilyev.ods_v_payment_etl as
(
with derived_columns as (
    select *,
           user_id::text            as user_key,
           account::text            as account_key,
           billing_period::text     as billing_period_key
    from sperfilyev.ods_t_payment
),
     hashed_columns as (
         select *,
                cast(md5(nullif(upper(trim(cast(user_id as varchar))), '')) as text)        as user_pk,
                cast(md5(nullif(upper(trim(cast(account as varchar))), '')) as text)        as account_pk,
                cast(md5(nullif(upper(trim(cast(billing_period as varchar))), '')) as text) as billing_period_pk,
                cast(md5(nullif(concat_ws('||',
                                          coalesce(nullif(upper(trim(cast(user_id as varchar))), ''), '^^'),
                                          coalesce(nullif(upper(trim(cast(account as varchar))), ''), '^^'),
                                          coalesce(nullif(upper(trim(cast(billing_period as varchar))), ''), '^^')
                                    ), '^^||^^||^^')) as text)                              as pay_pk,
                cast(md5(nullif(upper(trim(cast(phone as varchar))), '')) as text)          as user_hashdiff,
                cast(md5(nullif(concat_ws('||',
                                          coalesce(nullif(upper(trim(cast(pay_doc_num as varchar))), ''), '^^'),
                                          coalesce(nullif(upper(trim(cast(pay_doc_type as varchar))), ''), '^^'),
                                          coalesce(nullif(upper(trim(cast(pay_sum as varchar))), ''), '^^')
                                    ), '^^||^^||^^')) as text)                              as pay_hashdiff

         from derived_columns
     )
select user_key,
       account_key,
       billing_period_key,
       user_pk,
       account_pk,
       billing_period_pk,
       pay_pk,
       user_hashdiff,
       pay_hashdiff,
       pay_doc_type,
       pay_doc_num,
       pay_sum,
       phone,
       'PAYMENT_DATALAKE'::text as rec_source,
       pay_date as effective_from
from hashed_columns
    );

-- Проверки
select * from sperfilyev.ods_v_payment_etl limit 30;
select count(*) from sperfilyev.ods_t_payment;

-- ====================================================
-- Заполнение слоя ODS данными из STG
insert into sperfilyev.ods_t_payment (select * from sperfilyev.stg_t_payment);

-- Проверки
select count(*) from sperfilyev.ods_t_payment;
select * from sperfilyev.ods_t_payment limit 10;

select extract(year from pay_date) as pay_year, count(*)
from sperfilyev.ods_t_payment
group by pay_year
order by pay_year;

select count(distinct account) from sperfilyev.ods_t_payment;
select count(distinct billing_period) from sperfilyev.ods_t_payment;

-- Создаём доп.таблицу расширенную для хранения ключей, хэшдиффов итд
drop table if exists sperfilyev.ods_t_payment_hashed cascade;
create table sperfilyev.ods_t_payment_hashed as (
    select v.*,
           current_timestamp as load_dts
    from sperfilyev.ods_v_payment_etl as v);

insert into sperfilyev.ods_t_payment_hashed
select v.*,
       '2013-01-01'::date as load_dts
from sperfilyev.ods_v_payment_etl as v;

-- Проверки
select count(*) from sperfilyev.ods_t_payment_hashed;
select * from sperfilyev.ods_t_payment_hashed limit 10;

select count(distinct account_key) from sperfilyev.ods_t_payment_hashed;
select count(distinct billing_period_key) from sperfilyev.ods_t_payment_hashed;

select extract(year from effective_from) as pay_year, count(*)
from sperfilyev.ods_t_payment_hashed
group by pay_year
order by pay_year;

select load_dts, count(*)
from sperfilyev.ods_t_payment_hashed
group by load_dts
order by load_dts;
