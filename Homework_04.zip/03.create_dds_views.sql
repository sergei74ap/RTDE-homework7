-- ====================================================
-- Создаём ETL-вьюшки для загрузки данных в слой DDS DWH:

-- Для HUB'ов
-- Hub #1: User
drop view if exists sperfilyev.dds_v_hub_user_etl;
create view sperfilyev.dds_v_hub_user_etl as (
with users_numbered as (
    select user_pk,
           user_key,
           load_dts,
           rec_source,
           row_number() over (partition by user_pk order by load_dts asc) as row_num
    from sperfilyev.ods_t_payment_hashed),
     users_rank_1 as (
         select user_pk, user_key, load_dts, rec_source
         from users_numbered
         where row_num = 1),
     records_to_insert as (
         select a.*
         from users_rank_1 as a
                  left join sperfilyev.dds_t_hub_user as h
                            on a.user_pk = h.user_pk
         where h.user_pk is null
     )
select *
from records_to_insert
    );

-- Проверки
select * from sperfilyev.dds_v_hub_user_etl limit 20;
select count(*) from sperfilyev.dds_v_hub_user_etl;

-- -----------------------------------------
-- Hub #2: Account
drop view if exists sperfilyev.dds_v_hub_account_etl;
create view sperfilyev.dds_v_hub_account_etl as (
with accounts_numbered as (
    select account_pk,
           account_key,
           load_dts,
           rec_source,
           row_number() over (partition by account_pk order by load_dts asc) as row_num
    from sperfilyev.ods_t_payment_hashed),
     accounts_rank_1 as (
         select account_pk, account_key, load_dts, rec_source
         from accounts_numbered
         where row_num = 1),
     records_to_insert as (
         select a.*
         from accounts_rank_1 as a
                  left join sperfilyev.dds_t_hub_account as h
                            on a.account_pk = h.account_pk
         where h.account_pk is null
     )
select *
from records_to_insert
    );

-- Проверка
select * from sperfilyev.dds_v_hub_account_etl order by account_key;
select count(*) from sperfilyev.dds_v_hub_account_etl;
select count(distinct account_key) from sperfilyev.dds_v_hub_account_etl;

-- -----------------------------------------
-- Hub #3: Billing_period
drop view if exists sperfilyev.dds_v_hub_billing_period_etl;
create view sperfilyev.dds_v_hub_billing_period_etl as (
with billing_periods_numbered as (
    select billing_period_pk,
           billing_period_key,
           load_dts,
           rec_source,
           row_number() over (partition by billing_period_pk order by load_dts asc) as row_num
    from sperfilyev.ods_t_payment_hashed),
     billing_periods_rank_1 as (
         select billing_period_pk, billing_period_key, load_dts, rec_source
         from billing_periods_numbered
         where row_num = 1),
     records_to_insert as (
         select a.*
         from billing_periods_rank_1 as a
                  left join sperfilyev.dds_t_hub_billing_period as h
                            on a.billing_period_pk = h.billing_period_pk
         where h.billing_period_pk is null
     )
select *
from records_to_insert
    );

-- Проверка
select * from sperfilyev.dds_v_hub_billing_period_etl order by billing_period_key;
select count(*) from sperfilyev.dds_v_hub_billing_period_etl;
select count(distinct billing_period_key) from sperfilyev.dds_v_hub_billing_period_etl;

-- ----------------------------------------------------------------------
-- Для LINK'ов
-- Link #1: Payment (user - account - billing_period)
drop view if exists sperfilyev.dds_v_lnk_payment_etl;
create view sperfilyev.dds_v_lnk_payment_etl as (
select distinct p.pay_pk,
                p.user_pk,
                p.account_pk,
                p.billing_period_pk,
                p.effective_from,
                p.load_dts,
                p.rec_source
from sperfilyev.ods_t_payment_hashed as p
         left join sperfilyev.dds_t_lnk_payment as l
                   on p.pay_pk = l.pay_pk
where l.pay_pk is null
);

-- Проверка
select count(*) from sperfilyev.dds_v_lnk_payment_etl;
select * from sperfilyev.dds_v_lnk_payment_etl limit 20;
